# JSON-Parser
How to parse JSON using local data
